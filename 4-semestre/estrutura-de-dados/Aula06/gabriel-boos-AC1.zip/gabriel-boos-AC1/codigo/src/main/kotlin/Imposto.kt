package org.example

interface Imposto {
    fun getValorImposto(): Double
}