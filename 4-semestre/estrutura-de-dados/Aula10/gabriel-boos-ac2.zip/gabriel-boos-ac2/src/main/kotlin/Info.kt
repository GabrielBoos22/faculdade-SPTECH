package org.example

class Info(
    val ra: String,
    var aluno: String
){
    override fun toString(): String {
        return "Info ra: $ra, aluno: $aluno"
    }
}