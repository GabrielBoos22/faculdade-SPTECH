package org.example

interface Vendavel {
    fun getValorVenda(): Double
}