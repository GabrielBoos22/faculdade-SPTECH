package org.example

interface Bonificavel {
    fun getValorBonus(): Double
}