package org.example

interface Avaliado {
    fun avaliar(nota: Int, comentario: String)
    fun exibirAvaliacoes()
}