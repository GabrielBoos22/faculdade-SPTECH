fun main() {

    // 1- Criar uma lista mutável de objetos Paciente

    /* 2- Ler o arquivo paciente.txt que esta na pasta de projeto,
          criar um objeto Paciente para cada registro de dados do arquivo
          e adicionar esse objeto a lista criada acima.
          Mas atencao: se o paciente for prioritario, ele devera entrar no
          indice zero da lista, usando add(0,objeto)
          Se o paciente nao for prioritario, efetue add normal no fim da lista
          Atencao tambem para nao ficar com brancos excedentes nas variaveis texto
          A leitura deve seguir o documento de layout que esta na pasta do projeto
     */

    // 3- Exiba a lista de pacientes na console, sem usar saida formatada

    // 4- Grave o conteudo da lista num arquivo paciente.csv

    // 5- Leia o arquivo paciente.csv e exiba com saida formatada
    //    Nao se esqueca dos titulos das colunas
}