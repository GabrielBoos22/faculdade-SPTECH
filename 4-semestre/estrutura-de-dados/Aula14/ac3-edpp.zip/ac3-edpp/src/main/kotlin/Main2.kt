fun main() {

    // 6- Crie uma lista imutável com pelo menos 5 objetos Paciente.

    // De forma funcional e sem utilizar variáveis conclua os passos a seguir...

    // 7- Filtre a lista do passo 6 para conter apenas pacientes menores que 30 anos e exiba cada item da lista
    // em uma linha separada.

    // 8- Exiba a soma das idades de todos os pacientes.

    // 9- Exiba a soma dos pesos apenas dos pacientes prioritários.
}