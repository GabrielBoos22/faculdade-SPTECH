package school.sptech.projeto06downloadupload.controladora;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;
import school.sptech.projeto06downloadupload.dominio.Arquivo;
import school.sptech.projeto06downloadupload.repositorio.ArquivoRepository;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/arquivos")
public class ArquivoController {

  @Autowired
  private ArquivoRepository arquivoRepository;

  private Path diretorioBase = Path.of(System.getProperty("user.dir") + "/arquivos"); // projeto
//  private Path diretorioBase = Path.of(System.getProperty("java.io.tmpdir") + "/arquivos"); // temporario

  @PostMapping("/upload")
  public ResponseEntity<Arquivo> upload(@RequestParam("arquivo") MultipartFile file) { // recebe o arquivo na requisição como "multipart"

    // se o arquivo estiver vazio, já retorna 400
    if (file.isEmpty()){
      return ResponseEntity.status(400).build();
    }

    // se o diretório não existir, cria o diretório salvar o arquivo
    // obs: aqui está sendo feito desse jeito pois salva local
    if (!this.diretorioBase.toFile().exists()) {
      this.diretorioBase.toFile().mkdir();
    }

    // gera um nome aleatório para o arquivo, pois a identificação do arquivo é feita pelo nome e não por "id"
    String nomeArquivoFormatado = formatarNomeArquivo(file.getOriginalFilename());

    // indica aonde ficará o arquivo
    String filePath = this.diretorioBase + "/" + nomeArquivoFormatado;
    File dest = new File(filePath); // cria o objeto file com o caminho do arquivo de destino
    try {
      file.transferTo(dest); // salva o arquivo no diretório fazendo uma "transferência" do arquivo
    } catch (IOException e) {
      e.printStackTrace();
      throw new ResponseStatusException(422, "Não foi possível salvar o arquivo", null); // 422 - Unprocessable Entity
    }

    // Cria o objeto arquivo para salvar no banco o nome do arquivo para ser baixado posteriormente
    Arquivo arquivo = new Arquivo();
    arquivo.setDataUpload(LocalDate.now());
    arquivo.setNomeArquivoOriginal(file.getOriginalFilename());
    arquivo.setNomeArquivoSalvo(nomeArquivoFormatado);
    Arquivo arquivoBanco = arquivoRepository.save(arquivo);

    return ResponseEntity.status(200).body(arquivoBanco);
  }

  @GetMapping("/download/{id}")
  public ResponseEntity<byte[]> download(@PathVariable Integer id){
    // busca o objeto arquivo no banco
    Optional<Arquivo> arquivoOptional = arquivoRepository.findById(id);

    // se não encontrar o arquivo, retorna 404
    if (arquivoOptional.isEmpty()) {
      return ResponseEntity.status(404).build();
    }

    // se encontrar o arquivo, pega o objeto e o nome do arquivo salvo
    Arquivo arquivoBanco = arquivoOptional.get();

    // pega o arquivo salvo no diretório identificando ele pelo nome
    File file = this.diretorioBase.resolve(arquivoBanco.getNomeArquivoSalvo()).toFile();
    try {
      InputStream fileInputStream = new FileInputStream(file); // converte o arquivo em byte[]

      // retorna o arquivo para o cliente
      return ResponseEntity.status(200)
              .header("Content-Disposition",
                      "attachment; filename=" + arquivoBanco.getNomeArquivoOriginal()) // indica que o arquivo será baixado
              .body(fileInputStream.readAllBytes()); // retorna o arquivo em byte[]
    } catch (FileNotFoundException e) {
      e.printStackTrace();
      throw new ResponseStatusException(422, "Diretório não encontrado", null);
    } catch (IOException e) {
      e.printStackTrace();
      throw new ResponseStatusException(422, "Não foi possível converter para byte[]", null);
    }
  }

  // formata o nome do arquivo para ser salvo no diretório
  private String formatarNomeArquivo(String nomeOriginal) {
    return String.format("%s_%s", UUID.randomUUID(), nomeOriginal);
  }
}
