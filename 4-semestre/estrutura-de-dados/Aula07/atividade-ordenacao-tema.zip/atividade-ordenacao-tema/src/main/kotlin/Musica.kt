package org.example

import java.time.LocalDate

class Musica(
    val id: Int,
    val titulo: String,
    val duracao: Double,
    val classificacao: Int,
    val artista: String,
    val genero: String,
)