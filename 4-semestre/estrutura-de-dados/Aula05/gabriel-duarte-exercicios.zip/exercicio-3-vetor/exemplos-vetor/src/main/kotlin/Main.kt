fun main() {
    val nomes = Array(10) { "" }

    // Solicitando 10 nomes ao usuário
    for (i in nomes.indices) {
        println("Digite o ${i + 1}º nome:")
        nomes[i] = readln()
    }

    // Solicitando um nome para buscar
    println("Digite um nome para procurar:")
    val nomeProcurado = readln()

    // Pesquisando o nome no vetor
    val indice = nomes.contains(nomeProcurado)
    if (indice) {
        println("Nome encontrado no índice $indice")
    } else {
        println("Nome não encontrado")
    }
}
