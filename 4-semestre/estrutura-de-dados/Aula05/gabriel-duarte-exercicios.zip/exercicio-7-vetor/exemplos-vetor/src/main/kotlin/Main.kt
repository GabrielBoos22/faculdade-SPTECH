fun main() {
    val diasPorMes = arrayOf(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)

    // Solicitando que o usuário insira o dia e o mês
    println("Digite o dia (de 1 a 31):")
    val dia = readln().toInt()

    println("Digite o mês (de 1 a 12):")
    val mes = readln().toInt()

    // Calculando o número de dias desde o início do ano
    var diaDoAno = dia
    for (0..(mes - 2)) {
        diaDoAno += diasPorMes[i]
    }

    // Exibindo o resultado
    println("O dia $dia/$mes corresponde ao dia $diaDoAno do ano.")
}
