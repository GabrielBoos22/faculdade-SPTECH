fun main() {
    val diasSemana = arrayOf("Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado")

    var diaEscolhido: Int
    do {
        println("Digite um número entre 1 e 7 para saber o dia da semana:")
        diaEscolhido = readln().toInt()
    } while (diaEscolhido !in 1..7)

    // Exibindo o dia da semana correspondente
    println("O dia da semana correspondente é: ${diasSemana[diaEscolhido - 1]}")
}
