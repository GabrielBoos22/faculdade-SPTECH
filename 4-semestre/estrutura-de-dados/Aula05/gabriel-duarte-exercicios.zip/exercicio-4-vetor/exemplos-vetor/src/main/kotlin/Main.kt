fun mainmain() {
    val numeros = Array(10) { 0 }

    // Solicitando 10 números ao usuário
    for (i in numeros.indices) {
        println("Digite o ${i + 1}º número:")
        numeros[i] = readln().toInt()
    }

    // Solicitando um número para contar as ocorrências
    println("Digite um número para verificar quantas vezes ocorre:")
    val numeroProcurado = readln().toInt()

    // Contando quantas vezes o número ocorre
    val ocorrencias = numeros.count { it == numeroProcurado }
    println("O número $numeroProcurado ocorre $ocorrencias vezes")
}