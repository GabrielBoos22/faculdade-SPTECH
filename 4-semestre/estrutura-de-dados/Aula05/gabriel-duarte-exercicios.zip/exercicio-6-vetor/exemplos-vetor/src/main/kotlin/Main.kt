fun main() {
    val modelos = Array(5) { "" }
    val rendimentos = Array(5) { 0.0 }

    // Solicitando que o usuário insira os nomes dos carros
    for (i in modelos.indices) {
        println("Digite o nome do ${i + 1}º modelo de carro:")
        modelos[i] = readln()
    }

    // Solicitando que o usuário insira os rendimentos dos carros
    for (i in rendimentos.indices) {
        println("Digite o rendimento (km/L) do ${modelos[i]}:")
        rendimentos[i] = readln().toDouble()
    }

    // Encontrando o índice do carro mais econômico (maior rendimento)
    var indiceMaisEconomico = 0
    for (i in rendimentos.indices) {
        if (rendimentos[i] > rendimentos[indiceMaisEconomico]) {
            indiceMaisEconomico = i
        }
    }

    // Exibindo o carro mais econômico
    println("O carro mais econômico é o ${modelos[indiceMaisEconomico]} com rendimento de ${rendimentos[indiceMaisEconomico]} km/L")
}
