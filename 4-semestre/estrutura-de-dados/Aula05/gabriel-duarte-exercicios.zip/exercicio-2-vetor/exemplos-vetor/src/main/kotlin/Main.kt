fun main() {
    val numeros = Array(10) { 0 }

    // Solicitando 10 números ao usuário
    for (i in numeros.indices) {
        println("Digite o ${i + 1}º número:")
        numeros[i] = readln().toInt()
    }

    // Calculando a média
    val media = numeros.average()
    println("Média dos números: $media")

    // Exibindo números acima da média
    println("Números acima da média:")
    for (num in numeros) {
        if (num > media) {
            println(num)
        }
    }
}
