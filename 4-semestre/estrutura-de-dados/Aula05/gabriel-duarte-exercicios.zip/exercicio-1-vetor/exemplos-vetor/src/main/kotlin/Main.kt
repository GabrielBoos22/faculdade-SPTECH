fun main() {
    val numeros = Array(7) { 0 }

    // Solicitando que o usuário insira 7 números
    for (i in numeros.indices) {
        println("Digite o ${i + 1}º número:")
        numeros[i] = readln().toInt()
    }

    // Exibindo os números na ordem em que foram inseridos
    println("Números na ordem inserida:")
    for (num in numeros) {
        println(num)
    }

    // Exibindo os números na ordem inversa
    println("Números na ordem inversa:")
    for (i in numeros.indices.reversed()) {
        println(numeros[i])
    }
}
