package school.sptech.projetoestoque.dto

data class ProdutoSimplesResponse(
    var id: Int? = null,
    var nome: String? = null
)




