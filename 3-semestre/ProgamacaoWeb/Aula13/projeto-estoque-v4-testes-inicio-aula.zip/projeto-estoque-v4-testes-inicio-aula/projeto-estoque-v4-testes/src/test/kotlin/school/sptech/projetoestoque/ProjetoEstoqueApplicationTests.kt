package school.sptech.projetoestoque

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ProjetoEstoqueApplicationTests {

	@Test
	fun contextLoads() {
	}

}
