package school.sptech.projetoestoque.dto

// incompleto
data class FabricanteSimplesResponse(
  var codigo:Int? = null,
  var nome:String? = null,
)