package school.sptech.projetoestoque.dto

// incompleto
data class FabricanteCadastroRequest(
    var codigo: Int? = null,

    var nome: String? = null,

    var paisOrigem: String? = null
)
