package school.sptech.projetoestoque.service

import org.modelmapper.ModelMapper
import org.springframework.http.HttpStatusCode
import org.springframework.stereotype.Service
import org.springframework.web.server.ResponseStatusException
import school.sptech.projetoestoque.dominio.Fabricante
import school.sptech.projetoestoque.dto.FabricanteCadastroRequest
import school.sptech.projetoestoque.dto.FabricanteRelatorioResponse
import school.sptech.projetoestoque.repository.FabricanteRepository

@Service
class FabricanteService(
    var fabricanteRepository: FabricanteRepository,
    var mapper: ModelMapper = ModelMapper()
) {

    fun validarLista(lista:List<*>) {
        // incompleto
    }

    fun salvar(fabricante: FabricanteCadastroRequest): Fabricante? {
        // erro
        return null
    }

    fun getListaRelatorio(): List<FabricanteRelatorioResponse> {
        // erro
        return listOf()
    }

    fun validarIdFabricante(id:Int) {
        // incompleto
    }
}