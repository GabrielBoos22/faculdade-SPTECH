insert into fabricante (nome, pais_origem)
values
('Volvo', 'Suécia'), ('Honda', 'Japão'), ('Fiat', 'Itália');

insert into carro (modelo, potencia, importado, preco_compra, fabricante_codigo)
values
('Fit', 1.5, true, 46000, 2),
('City', 1.5, true, 50000, 2),
('Civic', 2.0, true, 55000, 2),
('XC60', 2.0, true, 70000, 1),
('EX30', 2.0, true, 80000, 1),
('Argo', 1.0, false, 80000, 3);