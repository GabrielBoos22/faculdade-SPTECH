package school.sptech.projetoestoque.controller

import jakarta.validation.Valid
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import school.sptech.projetoestoque.dominio.Fabricante
import school.sptech.projetoestoque.dto.FabricanteCadastroRequest
import school.sptech.projetoestoque.dto.FabricanteRelatorioResponse
import school.sptech.projetoestoque.service.FabricanteService

@RestController
@RequestMapping("/fabricantes")
class FabricanteController(
    val fabricanteService: FabricanteService
) {

    fun criar(@RequestBody @Valid novoFabricante: FabricanteCadastroRequest) : ResponseEntity<Fabricante> {
        return ResponseEntity.internalServerError().build()
    }

    fun listar(): ResponseEntity<List<FabricanteRelatorioResponse>> {
        return ResponseEntity.internalServerError().build()
    }
}