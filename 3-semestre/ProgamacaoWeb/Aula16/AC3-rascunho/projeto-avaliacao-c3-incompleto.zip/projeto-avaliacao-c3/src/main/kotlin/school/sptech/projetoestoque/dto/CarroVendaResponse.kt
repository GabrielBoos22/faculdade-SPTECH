package school.sptech.projetoestoque.dto

import com.fasterxml.jackson.annotation.JsonIgnore

// incompleto
data class CarroVendaResponse(
    var codigo: Int? = null,
    var modelo: String? = null,
    var potencia: Double? = null,
    var importado: Boolean? = null, // não deve retornar no JSON
    var precoCompra: Double? = null, // não deve retornar no JSON
    var fabricante: FabricanteSimplesResponse? = null // não deve retornar no JSON
) {

    fun getNomeFabricante(): String? {
        return ""
    }

    fun getPrecoVenda(): Double {
        return 0.0
    }
}




