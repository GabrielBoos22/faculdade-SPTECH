package school.sptech.projetoestoque.dominio

import jakarta.persistence.*

@Entity
data class Carro (
    @field:Id
    @field:GeneratedValue(strategy = GenerationType.IDENTITY)
    var codigo: Int? = null,

    var modelo: String? = null,

    var potencia: Double? = null,

    var precoCompra:Double? = null,

    var importado:Boolean? = false,

    @field:ManyToOne
    var fabricante: Fabricante? = null
)





