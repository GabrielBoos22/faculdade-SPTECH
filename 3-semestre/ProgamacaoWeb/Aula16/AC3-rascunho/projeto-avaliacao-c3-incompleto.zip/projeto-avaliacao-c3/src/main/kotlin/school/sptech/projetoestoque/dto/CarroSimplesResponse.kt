package school.sptech.projetoestoque.dto

// incompleto
data class CarroSimplesResponse(
    var codigo: Int? = null,
    var modelo: String? = null, // não deve retornar no JSON
    var potencia: Double? = null, // não deve retornar no JSON
    var fabricante: FabricanteRelatorioResponse? = null // não deve retornar no JSON
) {

    fun getDescricao(): String {
        return ""
    }

}




