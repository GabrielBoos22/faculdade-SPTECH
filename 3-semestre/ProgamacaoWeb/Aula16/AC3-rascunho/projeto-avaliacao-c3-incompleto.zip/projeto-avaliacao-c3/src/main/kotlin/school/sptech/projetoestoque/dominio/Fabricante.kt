package school.sptech.projetoestoque.dominio

import jakarta.persistence.*

@Entity
data class Fabricante (
    @field:Id
    @field:GeneratedValue(strategy = GenerationType.IDENTITY)
    var codigo: Int? = null,

    var nome: String? = null,

    var paisOrigem: String? = null,

    @field:OneToMany(mappedBy = "fabricante")
    var carros: List<Carro>? = null
)

