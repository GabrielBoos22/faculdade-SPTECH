package school.sptech.projetoestoque.controller

import jakarta.validation.Valid
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import school.sptech.projetoestoque.dominio.Carro
import school.sptech.projetoestoque.dto.CarroCadastroRequest
import school.sptech.projetoestoque.dto.CarroSimplesResponse
import school.sptech.projetoestoque.dto.CarroVendaResponse
import school.sptech.projetoestoque.service.CarroService

@RestController
@RequestMapping("/carros")
class CarrosController(
    val carroService: CarroService
) {

    fun criar(@RequestBody @Valid novoCarro: CarroCadastroRequest) : ResponseEntity<Carro> {
        return ResponseEntity.internalServerError().build()
    }

    fun listarSimples() : ResponseEntity<List<CarroSimplesResponse>> {
        return ResponseEntity.internalServerError().build()
    }

    fun listarContabil() : ResponseEntity<List<CarroVendaResponse>> {
        return ResponseEntity.internalServerError().build()
    }

}