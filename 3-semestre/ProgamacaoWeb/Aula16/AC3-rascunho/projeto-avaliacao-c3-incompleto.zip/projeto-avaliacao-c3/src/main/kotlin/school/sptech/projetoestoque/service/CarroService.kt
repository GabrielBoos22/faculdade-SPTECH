package school.sptech.projetoestoque.service

import org.modelmapper.ModelMapper
import org.springframework.http.HttpStatusCode
import org.springframework.stereotype.Service
import org.springframework.web.server.ResponseStatusException
import school.sptech.projetoestoque.dominio.Carro
import school.sptech.projetoestoque.dto.CarroCadastroRequest
import school.sptech.projetoestoque.dto.CarroSimplesResponse
import school.sptech.projetoestoque.dto.CarroVendaResponse
import school.sptech.projetoestoque.repository.CarroRepository

@Service
class CarroService(
    val carroRepository: CarroRepository,
    val fabricanteService: FabricanteService,
    val mapper: ModelMapper = ModelMapper()
) {

    fun validarLista(lista: List<*>) {
        // incompleto
    }

    fun validarIdProduto(id: Int) {
        if (!carroRepository.existsById(id)) {
            throw ResponseStatusException(HttpStatusCode.valueOf(404), "Carro $id não encontrado no sistema")
        }
    }

    fun getListaSimples(): List<CarroSimplesResponse> {
        // erro
        return listOf()
    }

    fun getListaVenda(): List<CarroVendaResponse> {
        // erro
        return listOf()
    }


    fun salvar(carro: CarroCadastroRequest): Carro {
        // incompleto

        fabricanteService.validarIdFabricante(carro.fabricante!!.codigo!!) // método incompleto

        val entidade = mapper.map(carro, Carro::class.java)
        carroRepository.save(entidade)
        return entidade
    }

    fun getSimples(id: Int): CarroSimplesResponse {
        validarIdProduto(id) // incompleto

        // erro
        return CarroSimplesResponse()
    }

}