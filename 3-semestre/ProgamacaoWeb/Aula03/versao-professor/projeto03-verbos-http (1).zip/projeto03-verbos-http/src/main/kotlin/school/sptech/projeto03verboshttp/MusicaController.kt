package school.sptech.projeto03verboshttp

import org.apache.coyote.Response
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/musicas")
class MusicaController {

    // lista vazia de musicas
    val listaMusicas: MutableList<Musica> = mutableListOf()

    // /musicas
    @GetMapping// Utilizamos GET para fazer listagem
    fun listar(): ResponseEntity<List<Musica>> {
        if (listaMusicas.isEmpty()) {
            return ResponseEntity.status(204).build() // 204 Not Content - Lista vazia
        }
        return ResponseEntity.status(200).body(listaMusicas) // 200 Ok - Lista com itens
    }

    // /musicas/0
    @GetMapping("/{indice}") // Utilizamos GET para buscar por indice
    fun buscaPorIndice(@PathVariable indice: Int): Musica? {
        if (existeMusica(indice)) {
            return listaMusicas[indice] // 200
        }

        return null // 404
    }

    // /musicas
    @PostMapping // Post - Utilizado para criação de algum recurso
    fun cadastrar(@RequestBody musica: Musica): Musica { // RequestBody - Receber JSON como objeto
        listaMusicas.add(musica)
        return musica
    }

    // /musicas/0
    @PutMapping("/{indice}") // PUT - Atualização completa de um recurso
    fun atualizar(
        @PathVariable indice: Int,
        @RequestBody musica: Musica): Musica? {

        if (existeMusica(indice)) {
            listaMusicas.set(indice, musica)
            return listaMusicas[indice]
        }
        return null
    }

    // /musicas/0
    @DeleteMapping("/{indice}") // DELETE - Utilizamos para deletar um recurso específico
    fun deletar(@PathVariable indice: Int) {
        if (existeMusica(indice)){
            listaMusicas.removeAt(indice)
        }
    }

    fun existeMusica(indice: Int): Boolean {
        return indice >= 0 && indice < listaMusicas.size
    }

}