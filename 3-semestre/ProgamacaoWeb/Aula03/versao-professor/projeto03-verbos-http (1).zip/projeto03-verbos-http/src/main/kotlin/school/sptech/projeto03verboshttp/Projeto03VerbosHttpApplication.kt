package school.sptech.projeto03verboshttp

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class Projeto03VerbosHttpApplication

fun main(args: Array<String>) {
	runApplication<Projeto03VerbosHttpApplication>(*args)
}
