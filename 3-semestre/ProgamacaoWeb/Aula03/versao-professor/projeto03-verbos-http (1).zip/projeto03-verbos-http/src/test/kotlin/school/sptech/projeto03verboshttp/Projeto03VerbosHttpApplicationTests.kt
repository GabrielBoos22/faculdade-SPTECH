package school.sptech.projeto03verboshttp

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class Projeto03VerbosHttpApplicationTests {

	@Test
	fun contextLoads() {
	}

}
