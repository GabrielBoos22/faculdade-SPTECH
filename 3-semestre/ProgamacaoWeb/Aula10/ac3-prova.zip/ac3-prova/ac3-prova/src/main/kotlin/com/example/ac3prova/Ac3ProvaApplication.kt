package com.example.ac3prova

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class Ac3ProvaApplication

fun main(args: Array<String>) {
	runApplication<Ac3ProvaApplication>(*args)
}
