
Insert into Sabor(nome, preco_base) values
('Calabresa', 30.0),
('Pepperoni', 35.0),
('Mussarela', 40.0);

    insert into Pizza(sabor_codigo, tamanho) values
    (1, 'PEQUENA'),
    (1, 'GRANDE'),
    (2, 'PEQUENA'),
    (2, 'GRANDE'),
    (3, 'PEQUENA'),
    (3, 'GRANDE');
