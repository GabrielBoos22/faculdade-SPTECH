package com.example.demo.domain

enum class Tamanho() {
    PEQUENA,
    MEDIA,
    GRANDE
}
