package sptech.projeto01

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class Projeto01Application

fun main(args: Array<String>) {
	runApplication<Projeto01Application>(*args)
}
